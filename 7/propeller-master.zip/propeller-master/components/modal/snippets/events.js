<script>
$('#myModal').on('hidden.bs.modal', function (e) {
  // do something...
})
</script>