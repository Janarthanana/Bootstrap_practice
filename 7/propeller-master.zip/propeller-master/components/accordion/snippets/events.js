<script>
$('#myCollapsible').on('hidden.bs.collapse', function (){
// do something…
});
</script>