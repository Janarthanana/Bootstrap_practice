<script>
$('#myDropdown').on('show.bs.dropdown', function () {
  // do something…
})
</script>