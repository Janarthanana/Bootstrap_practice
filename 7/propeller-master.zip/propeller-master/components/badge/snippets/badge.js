<!-- jquery js -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<!-- Propeller js -->
<script type="text/javascript" src="http://propeller.in/assets/js/propeller.min.js"></script>